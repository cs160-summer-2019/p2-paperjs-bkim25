from django.apps import AppConfig


class ColoringConfig(AppConfig):
    name = 'coloring'
